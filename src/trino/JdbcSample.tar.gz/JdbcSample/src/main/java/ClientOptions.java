// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

import static picocli.CommandLine.Option;

/**
 * Jdbc sample options
 */
public class ClientOptions {
    @Option(names = "--server", paramLabel = "<trino server endpoint>", description = "Trino host name, e.g. trino1.pool1.westeurope.projecthilo.net.", required = true)
    public String server;

    @Option(names = "--azure-tenant", paramLabel = "<tenant id>", description = "ID of Azure AD instance, represents a single organization.")
    public String azureTenant;

    @Option(names = "--azure-client", paramLabel = "<service principal application (client) id>", description = "App id of application registration. If provided used to get auth token.")
    public String azureClient;

    @Option(names = "--azure-secret", paramLabel = "<service principal application secret>", description = "Secret used to authenticate service principal/application")
    public String azureSecret;

    @Option(names = "--azure-certificate-path", paramLabel = "<service principal application certificate>", description = "Certificate used to authenticate service principal/application")
    public String azureCertificatePath;

    @Option(names = "--azure-use-token-cache", paramLabel = "<enable token caching>", description = "If true, will cache azure token in a shared encrypted token cache.")
    public Boolean azureUseTokenCache;

    @Option(names = "--auth", paramLabel = "<jdbc auth mode>", description = "Way to pass access token in JDBC connection, possible values: basic, accesstoken, AzureDefault, AzureInteractive, AzureClientSecret, AzureClientCertificate, AzureDeviceCode, AzureManagedIdentity")
    public String auth;

    @Option(names = "--query", paramLabel = "<query to execture>", defaultValue = "SELECT current_user as user", description = "Query to execute on trino cluster.")
    public String query;
}
