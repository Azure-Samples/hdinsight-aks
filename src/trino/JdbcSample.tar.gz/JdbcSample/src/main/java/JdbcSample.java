// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

import picocli.CommandLine;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Locale;
import java.util.Properties;
import java.util.concurrent.Callable;

@CommandLine.Command(
        name = "JdbcSample",
        header = "Sample application connecting to HDInsight Hilo Trino using jdbc driver.",
        synopsisHeading = "%nUSAGE:%n%n",
        optionListHeading = "%nOPTIONS:%n",
        usageHelpAutoWidth = true,
        mixinStandardHelpOptions = true)
public class JdbcSample implements Callable<Integer> {

    /**
     * Reserved username to be used with HDInsight Trino when connecting using basic auth
     */
    private static final String BASIC_USER_NAME_RESERVED = "OauthToken";

    /**
     * Parameter name where to pass jwt token in jdbc connection
     */
    private static final String ACCESS_TOKEN_CONNECTION_KEY = "accessToken";

    @CommandLine.Mixin
    public ClientOptions clientOptions;

    public static void main(String[] args) {
        System.exit(new CommandLine(new JdbcSample()).execute(args));
    }

    @Override
    public Integer call() {
        try {
            try (Connection connection = createConnection()) {
                try (Statement statement = connection.createStatement()) {
                    System.out.println("Execute query: " + clientOptions.query);
                    statement.execute(clientOptions.query);
                    printResultSet(statement.getResultSet());
                }
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            return 1;
        }

        return 0;
    }

    private Connection createConnection() throws Exception {
        String mode = clientOptions.auth != null ? clientOptions.auth.toLowerCase(Locale.getDefault()) : null;
        if (mode != null && (mode.equalsIgnoreCase("accesstoken") || mode.equalsIgnoreCase("basic"))) {
            return connectWithExternalToken();
        } else {
            return connectWithAzure();
        }
    }

    private Connection connectWithAzure() throws Exception {
        StringBuilder sb = new StringBuilder();

        sb.append(String.format("jdbc:trino://%s", clientOptions.server));
        if (clientOptions.auth != null) sb.append(String.format("?auth=%s", clientOptions.auth));
        if (clientOptions.azureTenant != null) sb.append(String.format("&azureTenant=%s", clientOptions.azureTenant));
        if (clientOptions.azureClient != null) sb.append(String.format("&azureClient=%s", clientOptions.azureClient));
        if (clientOptions.azureUseTokenCache != null) sb.append(String.format("&azureUseTokenCache=%s", clientOptions.azureUseTokenCache));
        if (clientOptions.azureSecret != null) sb.append(String.format("&password=%s", clientOptions.azureSecret));

        Properties props = new Properties();
        if (clientOptions.azureCertificatePath != null) props.put("azureCertificatePath", clientOptions.azureCertificatePath);

        String url = sb.toString();
        System.out.println(String.format("Creating JDBC connection: %s", url));
        return DriverManager.getConnection(url, props);
    }

    private Connection connectWithExternalToken() 
        throws Exception
    {
        if (clientOptions.azureTenant == null || clientOptions.azureClient == null || clientOptions.azureSecret == null) {
            throw new SQLException("TO get access token azure-client, azure-tenant, azure-secret are required.");
        }

        System.out.println(String.format("Getting azure access token in tenant %s.", clientOptions.azureTenant));
        String accessToken = TokenProvider.getAccessTokenByClientCredentialGrant(
                clientOptions.azureTenant,
                clientOptions.azureClient,
                clientOptions.azureSecret).accessToken();

        String url = String.format("jdbc:trino://%s:443", clientOptions.server);
        System.out.println(String.format("Creating JDBC connection to %s, mode %s", url, clientOptions.auth));

        boolean isBasic = clientOptions.auth.equalsIgnoreCase("basic");

        Properties properties = new Properties();
        if (isBasic) {
            // Set user name to reserved keyword for Hilo.
            properties.setProperty("user", BASIC_USER_NAME_RESERVED);
            // Pass access token in password field
            properties.setProperty("password", accessToken);
            // Do not specify access token otherwise
            properties.remove(ACCESS_TOKEN_CONNECTION_KEY);
        }
        else {
            properties.setProperty("user", "user1");
            properties.setProperty(ACCESS_TOKEN_CONNECTION_KEY, accessToken);
        }

        properties.setProperty("SSL", "true");
        return DriverManager.getConnection(url, properties);     
    }

    private void printResultSet(ResultSet rs) throws SQLException {
        ResultSetMetaData rsmd = rs.getMetaData();
        int columnsNumber = rsmd.getColumnCount();
        for (int i = 1; i <= columnsNumber; i++) {
            String postfix = i == columnsNumber ? "":", ";
            System.out.print(rsmd.getColumnName(i) + postfix);
        }
        System.out.println("");
        while (rs.next()) {
            for (int i = 1; i <= columnsNumber; i++) {
                String postfix = i == columnsNumber ? "":", ";
                String columnValue = rs.getString(i);
                System.out.print(columnValue + postfix);
            }
            System.out.println("");
        }
    }
}
