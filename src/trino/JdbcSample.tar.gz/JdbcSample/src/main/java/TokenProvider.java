// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

import com.microsoft.aad.msal4j.ClientCredentialFactory;
import com.microsoft.aad.msal4j.ClientCredentialParameters;
import com.microsoft.aad.msal4j.ConfidentialClientApplication;
import com.microsoft.aad.msal4j.IAuthenticationResult;

import java.net.MalformedURLException;
import java.util.Collections;

import static java.util.Objects.requireNonNull;

/**
 * Simple implementation of device-code token flow
 */
public class TokenProvider {
    private static final String AUTHORITY_FORMAT = "https://login.microsoftonline.com/%s";
    private static final String DEFAULT_SCOPE = "https://hilo.azurehdinsight.net/.default";

    
    public static IAuthenticationResult getAccessTokenByClientCredentialGrant(String tenantId, String clientId, String secret) throws MalformedURLException {        
        requireNonNull(tenantId);
        requireNonNull(clientId);
        requireNonNull(secret);

        String authority = String.format(AUTHORITY_FORMAT, tenantId);

        // Client credentials flow: https://docs.microsoft.com/en-us/azure/active-directory/develop/msal-authentication-flows#client-credentials
        // More code samples getting auth token: https://docs.microsoft.com/en-us/azure/active-directory/develop/sample-v2-code#service--daemon
        ConfidentialClientApplication app = ConfidentialClientApplication.builder(
                clientId,
                ClientCredentialFactory.createFromSecret(secret))
                .authority(authority)
                .build();

        // With client credentials flows the scope is ALWAYS of the shape "resource/.default", as the
        // application permissions need to be set statically (in the portal), and then granted by a tenant administrator
        ClientCredentialParameters clientCredentialParam = ClientCredentialParameters.builder(
                Collections.singleton(DEFAULT_SCOPE))
                .build();

        return app.acquireToken(clientCredentialParam).join();
    }
}
