# Overview
This sample project demonstrates usage of Azure Trino JDBC driver with AAD authentication.

# Install Azure Trino JDBC driver
[Install Azure Trino CLI](https://review.learn.microsoft.com/en-us/hdinsight-hilo/trino/trino-ui-cli?branch=main). JDBC driver jar is included in the CLI package and will be copied to your disk.

Locate JDBC jar file and install it into local maven repository.
```cmd
mvn install:install-file -Dfile=<trino-jdbc-*.jar> -DgroupId=io.trino -DartifactId=trino-jdbc -Dversion=410 -Dpackaging=jar -DgeneratePom=true
```

# Build and run
> [!NOTE] If required update pom.xml to refer to locally installed trino-jdbc maven package. By default install-file command above and sample pom.xml use **-Dversion=410**

Build sample:
```cmd
mvn clean install
```

See command-line parameters:
```cmd
java -jar JdbcSample-1.0-SNAPSHOT-executable.jar
```

Run with default authentication:
```cmd
java -jar JdbcSample-1.0-SNAPSHOT-executable.jar --server <cluster-endpoint>:443
```

Run with interactive authentication:
```cmd
java -jar JdbcSample-1.0-SNAPSHOT-executable.jar --server <cluster-endpoint>:443 --auth AzureInteractive
```

Run with interactive authentication caching token:
```cmd
java -jar JdbcSample-1.0-SNAPSHOT-executable.jar --server <cluster-endpoint>:443 --auth AzureInteractive --azure-use-token-cache
```

Run with service principal secret:
```cmd
java -jar JdbcSample-1.0-SNAPSHOT-executable.jar --server <cluster-endpoint>:443 --auth AzureClientSecret --azure-client 11111111-1111-1111-1111-111111111111 --azure-secret password1 --azure-tenant 11111111-1111-1111-1111-111111111111
```

# Resources
Read more about [Azure Trino JDBC driver](https://review.learn.microsoft.com/en-us/hdinsight-hilo/trino/trino-ui-jdbc-driver?branch=main)